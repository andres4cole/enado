<?php $__env->startSection('content'); ?>

				<div class="col-md-9">
              <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo e($about->title); ?></h3>
               <h5><?php echo e($about->name); ?> <span class="mailbox-read-time pull-right"> <?php echo e($about->created_at->format('Y M D, h:i:s')); ?></span></h5>
              <div class="box-tools pull-right">
                <button class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                <button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">
              <?php echo e($about->about); ?>

            </div><!-- /.box-body -->
            <div class="box-footer">

            	<ul class="mailbox-attachments clearfix">

            		   <li>
                      <span class="mailbox-attachment-icon has-img"><img src="<?php echo e(asset('files/about/'.$about->picture.'')); ?>" alt="Attachment" /></span>
                      <div class="mailbox-attachment-info">
                        <a href="#" class="mailbox-attachment-name"><i class="fa fa-camera"></i> picture </a>
                        <span class="mailbox-attachment-size">
                          2.67 MB
                          <a href="#" class="btn btn-default btn-xs pull-right"><i class="fa fa-cloud-download"></i></a>
                        </span>
                      </div>
                    </li>
                    <li>

            	</ul>
            	</div> <?php /* div box footer */ ?>
            	 <div class="box-footer">	
                  <div class="pull-right">
                    <a href="<?php echo e(url('admin/about/'.$about->id.'/edit')); ?>" class="btn btn-default"><i class="fa fa-edit"> </i>edit</a>

                     <form role="form" method="post" action="<?php echo e(url('admin/about/'.$about->id.'/delete')); ?>" id="form">
                      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                      <input type="hidden" name="_method" value="delete">
                      <input type="hidden" name="id" value="<?php echo e($about->id); ?>">
                      <button class="btn btn-default"><i class="fa fa-trash-o"></i> Delete</button>
                     </form>

                 </div>
            </div><!-- /.box-footer-->
          </div><!-- /.box -->
      </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('sidebar'); ?>




<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>