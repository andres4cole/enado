<?php $__env->startSection('content'); ?>



 <div class="col-md-6">
              <!-- general form elements -->
              <div class="box box-solid">
                <div class="box-header with-border">
                  <h3 class="box-title">create new developer</h3>
                </div><!-- /.box-header -->
                 <!-- form start -->
                <form role="form" method="Post" action="<?php echo e(url('/admin/developer/'.$developer->id.'/update')); ?>" enctype="multipart/form-data" id="form" >
                  <div class="box-body">
                   <input type="hidden" name="_token"  value="<?php echo e(csrf_token()); ?>" >
                   <input type="hidden" name="userid"  value="<?php echo e(Auth::user()->id); ?>" >


                    <div class="form-group <?php echo e($errors->has('firstname') ? 'has-error' : ''); ?> ">
                      <label for="firstname">firstname</label>
                      <input type="text" id="firstname" class="form-control" name="firstname"  placeholder="firstname" value="<?php echo e($developer->firstname); ?>">
                      <div class="error help-block"><?php echo e($errors->first('firstname')); ?></div>
                       </div>

                        <div class="form-group <?php echo e($errors->has('lastname') ? 'has-error' : ''); ?> ">
                      <label for="lastname">lastname</label>
                      <input type="text" id="" class="form-control" name="lastname"  placeholder="lastname" value="<?php echo e($developer->lastname); ?>">
                      <div class="error help-block"><?php echo e($errors->first('lastname')); ?></div>
                       </div>


                         <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?> ">
                      <label for="email">email</label>
                      <input type="email" id="email" class="form-control" name="email"  placeholder="yourname@example.com" value="<?php echo e($developer->email); ?>">
                      <div class="error help-block"><?php echo e($errors->first('email')); ?></div>
                       </div>


                  

                         <div class="form-group <?php echo e($errors->has('postion') ? 'has-error' : ''); ?> ">
                      <label for="position">postion</label>
                      <input type="text" id="" class="form-control" name="position"  placeholder="position" value="<?php echo e($developer->position); ?>">
                      <div class="error help-block"><?php echo e($errors->first('position')); ?></div>
                       </div>

                         <div class="form-group <?php echo e($errors->has('skills') ? 'has-error' : ''); ?> ">
                      <label for="skills">skills</label>
                      <input type="text" id="skills" class="form-control" name="skills"  placeholder="skills" value="<?php echo e($developer->skills); ?>">
                      <div class="error help-block"><?php echo e($errors->first('skills')); ?></div>
                       </div>

                         <div class="form-group <?php echo e($errors->has('about') ? 'has-error' : ''); ?> ">
                      <label for="about">about</label>
                      <textarea id="about" row="5" col="10" class="form-control" name="about"  placeholder="about" value=""><?php echo e($developer->about); ?></textarea>
                      <div class="error help-block"><?php echo e($errors->first('about')); ?></div>
                       </div>


                        <div class="form-group  <?php echo e($errors->has('gender') ? 'has-error' : ''); ?>">
                        <lable for="country">select gender </lable>
                        <select  class="form-control" name="gender"  value="<?php echo e($developer->gender); ?>" id="">
                         <option value="Male">Male</option>
                         <option value="Female">Female</option>
                         </select>
                            <div class="error"><?php echo e($errors->first('gender')); ?></div>
                      </div>




                           <div class="form-group <?php echo e($errors->has('phone') ? 'has-error' : ''); ?> ">
                      <label for="phone">phone number</label>
                      <input type="number" id="phone" class="form-control" name="phone"  placeholder="phone number" value="<?php echo e($developer->phone); ?>">
                      <div class="error help-block"><?php echo e($errors->first('phone')); ?></div>
                       </div>

                          <div class="form-group  <?php echo e($errors->has('country') ? 'has-error' : ''); ?>">
                        <lable for="country">select country </lable>
                        <select  class="form-control" name="country"  value="<?php echo e($developer->country); ?>" id="">
                         <?php foreach($country as $country): ?>
                         <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                          <?php endforeach; ?>
                         </select>
                            <div class="error"><?php echo e($errors->first('country')); ?></div>
                      </div>



                       <div class="form-group <?php echo e($errors->has('state') ? 'has-error' : ''); ?> ">
                      <label for="state">state</label>
                      <input type="text" id="state" class="form-control" name="state"  placeholder="state" value="<?php echo e($developer->state); ?>">
                      <div class="error help-block"><?php echo e($errors->first('state')); ?></div>
                       </div>

                        <div class="form-group <?php echo e($errors->has('city') ? 'has-error' : ''); ?> ">
                      <label for="city">city</label>
                      <input type="text" id="city" class="form-control" name="city"  placeholder="city" value="<?php echo e($developer->city); ?>">
                      <div class="error help-block"><?php echo e($errors->first('city')); ?></div>
                       </div>

                      <div class="form-group <?php echo e($errors->has('picture') ? 'has-error' : ''); ?>">
                    <div class="btn btn-default btn-file">
                      <i class="fa fa-paperclip"></i> display image
                      <input type="file" name="picture" id="picture"value="<?php echo e($developer->picture); ?>"  />
                       <div class="error help-block"><?php echo e($errors->first('picture')); ?></div>
                    </div>
                    <p class="help-block">Max. 2MB</p>
                  </div>

                    <div class="form-group <?php echo e($errors->has('cover') ? 'has-error' : ''); ?>">
                    <div class="btn btn-default btn-file">
                      <i class="fa fa-paperclip"></i>cover picture
                      <input type="file" name="cover" id="cover" value="<?php echo e($developer->cover_image); ?>" >
                       <div class="error help-block"><?php echo e($errors->first('cover')); ?></div>
                    </div>
                    <p class="help-block">Max. 2MB</p>

                  
                      </div><!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
              </div><!-- /.box -->
            </div>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('sidebar'); ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>