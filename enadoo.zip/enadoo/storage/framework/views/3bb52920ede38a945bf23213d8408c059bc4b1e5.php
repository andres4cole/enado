<?php $__env->startSection('headerapp'); ?>
<section id="headerapp" style="background-image: url('<?php echo e(asset('/frontend/images/port-1.jpg')); ?>')">
    <h2 class="newsh">Portfolio</h2>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="col-md-8">
	<h2 class="newsh2">OUR PORTFOLIO</h2>

     <div class="row">

   <?php foreach($portfolios as $portfolio): ?>
   <div class="col-md-6 col-sm-6 col-xs-12 portfolio-main">

   	<a href="<?php echo e(url('portfolio/'.$portfolio->id.'')); ?> "><img src="<?php echo e(asset('files/portfolio/'.$portfolio->image.'')); ?>" class="img-responsive"/></a>
    <p>
     <?php /* $portfolio-> */ ?>
     <h4><?php echo e($portfolio->name); ?></h4>
      <h6><?php echo e($portfolio->title); ?></h6>
     <strong>Client:</strong> <?php echo e($portfolio->client); ?>

     <br><a href="<?php echo e(url('portfolio/'.$portfolio->id.'')); ?>" class="btn btn-primary btn-sm">Read More</a>
    </p>

    </div>
   <?php endforeach; ?>

    <?php echo $portfolios->render(); ?>

</div>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('include.proposal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>