<?php $__env->startSection('headerapp'); ?>
<section id="headerapp" style="background-image: url('<?php echo e(asset('/frontend/images/dev1.jpg')); ?>')">
    <h2 class="newsh">Our Developer team</h2>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

            <div class="col-md-8">
			<?php foreach($developers as $developer): ?>

 
   					<div class="col-md-6 col-sm-6">

                    <div class="user-header" style="background-image: url(<?php echo e(asset('files/developer/cover/'.$developer->cover_image.'')); ?>);">
                   <img src=" <?php echo e(asset('files/developer/picture/'.$developer->picture.'')); ?>" class="img-circle " alt="<?php echo e($developer->firstname); ?>"/>
                    <p>
                      <a href="<?php echo e(url('/developer/'.$developer->id.'')); ?>"><?php echo e($developer->firstname); ?> <?php echo e($developer->lastname); ?></a> 
                      	<br> <?php echo e($developer->position); ?> 
                      <small class="hidden-xs">Member since <?php echo e($developer->created_at->format('M Y')); ?>.</small>
                    </p>
                  </div>
                  <!-- Menu Body --> 
                      
              </div>
              <?php endforeach; ?>
              <?php echo $developers->render(); ?>

              </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('sidebar'); ?>

<?php echo $__env->make('include.proposal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>