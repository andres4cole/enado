        <?php $__env->startSection('content'); ?>
	
			
    <section id="error" class="container text-center">

    	<div class="cool-md-12">
        <h1>404, Page not found</h1>
        <p>The Page you are looking for doesn't exist or an other error occurred.</p>
        <p class="pull-center"><a  href="<?php echo e(url('/')); ?>"  class="btn btn"  > GO BACK TO THE HOME</a></p>
    </div>
    </section><!--/#error  class="btn btn-default"-->

		
		<?php $__env->stopSection(); ?>



<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>