<?php $__env->startSection('headerapp'); ?>
<section id="headerapp" style="background-image: url('<?php echo e(asset('/frontend/images/wps.jpg')); ?>')">
    <h2 class="newsh">Press Release</h2>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

				<div class="col-md-8">
					<h2 class="newsh2">Latest News from Enadoo </h2>
					<div class="row">
					<?php foreach($news as $new): ?>
						<div class="col-md-6 news">
							<img src="<?php echo e(asset('files/news/'.$new->picture.'')); ?>" title="name" />
							<h4><a href="<?php echo e(url('news/'.$new->id.'')); ?>"> <?php echo e($new->title); ?> </a></h4>
							<span><?php echo e($new->created_at->format('d M Y')); ?> <?php /* by <a href="#">Admin</a></span> */ ?>
							<p> <?php echo e(substr($new->news, 0, 190)); ?>.... </p>
							<a class="news-btn" href="<?php echo e(url('news/'.$new->id.'')); ?>">Read More</a>
						</div>
						<?php endforeach; ?>
						<?php echo $news->render(); ?>

					</div>
				</div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('sidebar'); ?>

<?php echo $__env->make('include.proposal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>