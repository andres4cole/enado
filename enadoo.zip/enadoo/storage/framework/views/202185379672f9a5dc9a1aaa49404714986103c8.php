<?php $__env->startSection('content'); ?>


<?php foreach($portfolios as $portfolio): ?>
        <div class="col-md-4 col-sm-6">
						<div class="portfolio-item">
							<div class="portfolio-image">
								<a href="<?php echo e(url('admin/portfolio/v/'.$portfolio->id.'')); ?> "> <img src="<?php echo e(asset('/files/portfolio/'.$portfolio->image.'')); ?>" alt="<?php echo e($portfolio->name); ?>"></a>
							</div>
							<div class="portfolio-info">
								<ul>
									<li class="portfolio-project-name"><?php echo e($portfolio->name); ?></li>
									<li><?php echo e($portfolio->title); ?></li>
									<li><strong>Client:</strong> <?php echo e($portfolio->client); ?> </li>
									
									<li class="read-more btn-line"><a href="<?php echo e(url('admin/portfolio/v/'.$portfolio->id.'')); ?> " class="btn btn-default">Read more</a></li>
						           <li class="read-more btn-line"><a href=" <?php echo e(url('admin/portfolio/'.$portfolio->id.'/edit')); ?> " class="btn btn-default">Edit</a></li>
                      

                      <li><form role="form" method="post" action="<?php echo e(url('admin/portfolio/'.$portfolio->id.'/delete')); ?>" id="form">
                      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                      <input type="hidden" name="_method" value="delete">
                      <input type="hidden" name="id" value="<?php echo e($portfolio->id); ?>">
                      <button class="fa fa-trash-o"></button>
					  </form>
					</li>

								</ul>
							</div>
						</div>
       					</div>
       					<?php endforeach; ?>

       						<?php echo e($portfolios->render()); ?>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('sidebar'); ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>