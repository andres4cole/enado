<?php $__env->startSection('headerapp'); ?>
<section id="headerapp" style="background-image: url('<?php echo e(asset('/frontend/images/wps.jpg')); ?>')">
    <h2 class="newsh">our services</h2>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
         
                <div class="services service-item">
              <?php foreach($services as $service): ?>
                <div class="col-sm-6 col-md-4">
                    <div class="media services-wrap wow fadeInDown">                        
                        <img src="<?php echo e(asset('files/services/'.$service->picture.'')); ?>">
                        <h3 class="box-header"><?php echo e($service->title); ?></h3>
                        <div class="box-body">
                            <p><?php echo e($service->service); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>

          </div><!--/#services-->

<?php $__env->stopSection(); ?>



<?php $__env->startSection('sidebar'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>