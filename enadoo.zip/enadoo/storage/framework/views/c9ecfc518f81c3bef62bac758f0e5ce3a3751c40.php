<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->yieldContent('meta'); ?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Innovative web design ans social utility">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo e($site->description); ?>">
    <meta name="author" content="Nosakhare Andrew">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>  <?php echo e($site->title); ?></title>
	<?php /* asset('bt/') */ ?>
	<!-- core CSS -->
    <link href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/css/animate.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/css/prettyPhoto.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/css/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/css/responsive.css')); ?>" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="<?php echo e(asset('frontend/images/ico/icon.ico')); ?>">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo e(asset('frontend/images/ico/icon.png')); ?>">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo e(asset('frontend/images/ico/icon144.png')); ?>">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo e(asset('frontend/images/ico/icon1.png')); ?>">
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(asset('frontend/images/ico/icon2.png')); ?>">

</head><!--/head-->

<body class="homepage" style="background-image: url(<?php echo e(asset('/files/setting/background/'.$site->background_image.'')); ?>)">

    <header id="header">
        <div class="top-bar">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-xs-6">
                        <div class="top-number "><p><i class="fa fa-phone-square"></i><?php echo e($site->phone); ?></p></div>
                    </div>
                    <div class="col-sm-6 col-xs-6">
                       <div class="social">
                            <ul class="social-share">
                                <li><a href="//facebook.com/<?php echo e($site->facebook); ?>"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="//twitter.com/<?php echo e($site->twitter); ?>"><i class="fa fa-twitter"></i></a></li>
                            </ul>
                            <div class="search hidden-xs">
                                <form role="form">
                                    <input type="text" class="search-form" autocomplete="off" placeholder="Search">
                                    <i class="fa fa-search"></i>
                                </form>
                           </div>
                       </div>
                    </div>
                </div>
            </div><!--/.container-->
        </div><!--/.top-bar-->

        <nav class="navbar navbar-inverse" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('files/setting/logo/'.$site->logo.'')); ?>" alt="Enado"></a>
                </div>
				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                       <li class="<?php echo e((Request::is('about') ? 'active' : '')); ?> "><a href="<?php echo e(url('about')); ?>">about</a></li>
                       <li class="<?php echo e((Request::is('services') ? 'active' : '')); ?> "><a href="<?php echo e(url('services')); ?>">services</a></li>
                       <li class="<?php echo e((Request::is('portfolio') ? 'active' : '')); ?> "><a href="<?php echo e(url('portfolio')); ?>">portfolio</a></li>
                       <li class="<?php echo e((Request::is('news') ? 'active' : '')); ?> "><a href="<?php echo e(url('news')); ?>">news</a></li>
                       <li class="<?php echo e((Request::is('testimonies') ? 'active' : '')); ?> "><a href="<?php echo e(url('testimonies')); ?>">testimonies</a></li>
                       <li class="<?php echo e((Request::is('contact') ? 'active' : '')); ?> "><a href="<?php echo e(url('contact')); ?>">contact</a></li>
                      <li class="<?php echo e((Request::is('request') ? 'active' : '')); ?> "><a href="<?php echo e(url('request')); ?>">proposal</a></li>
                       <li class="<?php echo e((Request::is('developer') ? 'active' : '')); ?> "><a href="<?php echo e(url('developer')); ?>">developer</a></li>
                 
                                             
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->
		
    </header><!--/header-->

<?php echo $__env->yieldContent('slider'); ?>
<?php echo $__env->yieldContent('headerapp'); ?>

 <?php if(Session::has('success_msg')): ?>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
     <div class="alert alert-success">
        <span class="glyphicon glyphicon-check"> <?php echo e(Session::get('success_msg')); ?></span>
    </div>
   </div>
  </div>
</div>
    <?php endif; ?>

     <?php if(Session::has('error_msg')): ?>
     <div class="container">
    <div class="row">
     <div class="col-md-12">
     <div class="alert alert-danger">
        <span class="glyphicon glyphicon-check"> <?php echo e(Session::get('error_msg')); ?></span>
    </div>
     </div>
     </div>
      </div>
    <?php endif; ?>

<section class="container"><!-- section start here, sorry if you are developer fuck u -->
<div class="row">

 <?php echo $__env->yieldContent('content'); ?>
 <?php echo $__env->yieldContent('sidebar'); ?>
    
</div>
</section><!-- section ends here -->



   <div class="mid-footer footer-background">
        <div class="container">

                      <div class="row">
                    <div class="col-footer col-md-3 col-sm-6 col-xs-12">
                    
                        <h3>Our Latest Work</h3>
                        <div class="portfolio-picture">
                        <?php foreach($portfolio as $portfolio): ?>  
                 <a href="<?php echo e(url('portfolio/'.$portfolio->id.'')); ?> "><img src="<?php echo e(asset('/files/portfolio/'.$portfolio->image.'')); ?>" alt="<?php echo e($portfolio->name); ?>"></a>
                           
                        <?php endforeach; ?>
                    </div>
                </div>


                    
                    <div class="col-footer col-md-3 col-sm-6 col-xs-12 mid-contact">
                        <h3>Contacts</h3>
                        <p class="contact-us-details">
                            <b>Address:</b><?php echo e($site->address); ?><br/>
                            <b>Phone:</b> <?php echo e($site->phone); ?><br/>
                            <b>Fax:</b> <?php echo e($site->fax); ?><br/>
                            <b>Email:</b> <a href="<?php echo e($site->email); ?>"><?php echo e($site->email); ?></a>
                        </p>
                        <h4> subscrbe to our newsletter </h4>
                        <div class="form-close">
                          <form class="form-horizontal" role="form" id="form" action=" <?php echo e(url('/save/e')); ?>" method="post">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <div class="form-group input-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                            <input type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="enter email address" class="form-control input-sm" id="email">
                            <div class="error"> <?php echo e($errors->first('email')); ?></div>
                            <span class="input-group-btn">
                                <button type="submit" class="btn btn-default btn-sm">GO</button>
                            </span>
                        </div>
                          </form>
                      </div>
                    </div>

                      <div class="col-footer col-md-3 col-sm-6 col-xs-12">
                       <h3>menu</h3>
                       <ul class="menu-space">
                        <li><a href="<?php echo e(url('about')); ?>">about us</a></li>
                        <li><a href="<?php echo e(url('contact')); ?>">contact us</a></li>
                        <li><a href="<?php echo e(url('portfolio')); ?>">portfolio</a></li>
                        <li><a href="<?php echo e(url('services')); ?>">services</a></li>
                        <li><a href="<?php echo e(url('news')); ?>">news</a></li>
                        <li><a href="<?php echo e(url('testimonies')); ?>">testimony</a></li>
                        <li><a href="<?php echo e(url('developer')); ?>">developer</a></li>
                        <li><a href="<?php echo e(url('request')); ?>">Proposal</a></li>
                       </ul>
                                              
                   
                    </div>
                    <div class="col-footer col-md-3 col-sm-6 col-xs-12">
                        <h3>Stay Connected</h3>
                        <ul class="footer-stay-connected no-list-style">
                            <li><a href="//facebook.com/<?php echo e($site->facebook); ?>" class="facebook"></a></li>
                            <li><a href="//twitter.com/<?php echo e($site->twitter); ?>" class="twitter"></a></li>
                            <li><a href="//google.com/<?php echo e($site->google); ?>" class="googleplus"></a></li>
                        </ul>
            
                    </div>
               
                </div>
             </div>
         </div>



 <?php echo $__env->yieldContent('footer'); ?>
        <footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    &copy; 2012 - <?php echo e(date('Y')); ?> <a target="_blank" href="" title=""> Enadoo inc </a>. All Rights Reserved.
                </div>
                <div class="col-sm-6">
                    <ul class="pull-right">
                        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                         <li><a href="<?php echo e(url('about')); ?>">About us</a></li>
                          <li><a href="<?php echo e(url('support')); ?>">support</a></li>
                           <li><a href="<?php echo e(url('contact')); ?>">Contact us</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer><!--/#footer-->



    <script src="<?php echo e(asset('frontend/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/jquery.prettyPhoto.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/jquery.isotope.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/wow.min.js')); ?>"></script>


</body>
</html>