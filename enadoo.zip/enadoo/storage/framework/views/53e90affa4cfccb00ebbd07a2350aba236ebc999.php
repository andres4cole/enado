<?php $__env->startSection('content'); ?>

   <div class="col-md-8 col-sm-12">
                    <div class="user-header" style="background-image: url(<?php echo e(asset('files/developer/cover/'.$developer->cover_image.'')); ?>);">
                    <img src=" <?php echo e(asset('files/developer/picture/'.$developer->picture.'')); ?>" class="img-circle " alt=" <?php echo e($developer->firstname); ?> <?php echo e($developer->lastname); ?>" />
                    <div class="buttons-sm">
                    <p>
                      <?php echo e($developer->firstname); ?> <?php echo e($developer->lastname); ?> - <?php echo e($developer->position); ?> 
                      <small>Member since <?php echo e($developer->created_at->format('M Y')); ?>.</small>
                    </p>
                  </div>
                </div>
                  <!-- Menu Body -->
                  <div class="user-body">
                    <div class="col-xs-4 text-center">
                      <a href="#">followers</a>
                    </div>
                    <div class="col-xs-4 text-center">
                      <a href="#">Sales</a>
                    </div>
                    <div class="col-xs-4 text-center">
                      <a href="#">Friends</a>
                    </div>

                          <h2>contact Details</h2>
                    <br><span>Email:</span> <?php echo e($developer->email); ?></br>
                    <br><span>Phone number:</span> <?php echo e($developer->phone); ?></br>
                    
                    <h2>About me</h2>
                    <p><?php echo e($developer->about); ?></p>
                    <br><strong>skills:</strong> <?php echo e($developer->skills); ?></br>
                    <br><span>Gender:</span> <?php echo e($developer->gender); ?></br>
                    <h2>location</h2>
                    <br><strong>Country:</strong> <?php echo e($developer->country); ?></br>
                    <br><strong>State:</strong> <?php echo e($developer->state); ?></br>
                    <br><strong>City:</strong> <?php echo e($developer->city); ?></br>
                    <br><strong>Status:</strong> <?php echo e($developer->status); ?> member</br>

                  </div> 

            
                  <!-- Menu Footer-->
                  <div class="user-footer">
                      <a href="<?php echo e(url('/admin/developer/'.$developer->id.'')); ?>" class="btn btn-default btn-flat">Profile</a>
                       <a href="<?php echo e(url('/admin/developer/'.$developer->id.'/edit')); ?>" class="btn btn-default btn-flat btn-line">Edit</a> 
                        <form role="form" method="post" action="<?php echo e(url('admin/developer/'.$developer->id.'/delete')); ?>" id="form">
                      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                      <input type="hidden" name="_method" value="delete">
                      <input type="hidden" name="id" value="<?php echo e($developer->id); ?>">
                      <button class="btn btn-default fa fa-trash-o"></button>
					  </form>
                    </div>
                 
              </div>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('sidebar'); ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>