  <?php $__env->startSection('headerapp'); ?>

<section id="headerapp" style="background-image: url('<?php echo e(asset('/files/about/'.$about->picture.'')); ?>')">
	
	<h2> <?php echo e($about->title); ?> </h2>
</section>
  <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $about->about; ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('sidebar'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>