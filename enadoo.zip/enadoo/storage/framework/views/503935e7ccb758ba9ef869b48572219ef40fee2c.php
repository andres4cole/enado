<?php $__env->startSection('content'); ?>


 <div class="col-md-6 col-sm-6 portfolio-main">
 	<h2 class="newsh2"><?php echo e($portfolio->name); ?></h2>
   	<img src="<?php echo e(asset('files/portfolio/'.$portfolio->image.'')); ?>"/>
   </div>

 <div class="col-md-6 col-sm-6 portfolio-main">
    <h2 class="newsh2"><?php echo e($portfolio->title); ?></h2>
  	           <div class="panel-body">
						<p>
						<?php echo e($portfolio->description); ?>

						</p>
					  <ul>
							<li><b>Client:</b> <?php echo e($portfolio->client); ?>.</li>
							<li><b>budget:</b> <?php echo e($portfolio->budget); ?></li>
							 <li><b>Cost:</b> <?php echo e($portfolio->cost); ?></li>
							<li><b>Start Date:</b> <?php echo e($portfolio->created_at->format('M d, Y')); ?> </li> 
							<li><b>End Date:</b> <?php echo e($portfolio->end_time); ?></li>
							<li><b>Technologies:</b> <?php echo e($portfolio->technologies); ?></li>
							<li class="btn btn-primary btn-sm"><a href="<?php echo e($portfolio->website); ?>">Visit Website</a></li>
					      </ul>  
					</div>
    </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('sidebar'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>