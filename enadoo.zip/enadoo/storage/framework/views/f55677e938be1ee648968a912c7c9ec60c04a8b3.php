<?php $__env->startSection('content'); ?>


   					<?php foreach($developers as $developer): ?>
            


   					<div class="col-md-4 col-sm-6">
                    <div class="user-header" style="background-image: url(<?php echo e(asset('files/developer/cover/'.$developer->cover_image.'')); ?>);">
                    <img src=" <?php echo e(asset('files/developer/picture/'.$developer->picture.'')); ?>" class="img-circle " alt="<?php echo e($developer->firstname); ?> <?php echo e($developer->lastname); ?>" />
                    <p class="buttons-sm">
                      <?php echo e($developer->firstname); ?> <?php echo e($developer->lastname); ?> - <?php echo e($developer->position); ?> 
                      <small>Member since <?php echo e($developer->created_at->format('M Y')); ?>.</small>
                    </p>
                  </div>
                  <!-- Menu Body -->
                  <div class="user-body">
                    <div class="col-xs-4 text-center">
                    <a href="<?php echo e(url('/admin/developer/v/'.$developer->id.'')); ?>">Profile</a>
                    </div>
                    <div class="col-xs-4 text-center">
                       <a href="<?php echo e(url('/admin/developer/'.$developer->id.'/edit')); ?>">Edit</a> 
                    </div>
                    <div class="col-xs-4 text-center">
                   <a href="">hire Me</a>
                    </div>
                  </div>
         
                 
              </div>
              <?php endforeach; ?>

              <?php echo e($developers->render()); ?>

 


<?php $__env->stopSection(); ?>



<?php $__env->startSection('sidebar'); ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>