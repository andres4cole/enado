<?php $__env->startSection('slider'); ?>



   <section id="main-slider" class="no-margin">
        <div class="carousel slide">
            <ol class="carousel-indicators">
                <li data-target="#main-slider" data-slide-to="0" class="active"></li>
                <li data-target="#main-slider" data-slide-to="1"></li>
                <li data-target="#main-slider" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">

                <div class="item active" style="background-image: url(http://localhost/tut/corlate/images/slider/bg1.jpg)">
                    <div class="container">
                        <div class="row slide-margin">
                            <div class="col-sm-6">
                                <div class="carousel-content">
                                    <h1 class="animation animated-item-1">Lorem ipsum dolor sit amet consectetur adipisicing elit</h1>
                                    <h2 class="animation animated-item-2">Accusantium doloremque laudantium totam rem aperiam, eaque ipsa...</h2>
                                    <a class="btn-slide animation animated-item-3" href="#">Read More</a>
                                </div>
                            </div>

                            <div class="col-sm-6 hidden-xs animation animated-item-4">
                                <div class="slider-img">
                                    <img src="http://localhost/tut/corlate/images/slider/img1.png" class="img-responsive">
                                </div>
                            </div>

                        </div>
                    </div>
                </div><!--/.item-->

                <div class="item" style="background-image: url(http://localhost/tut/corlate/images/slider/bg2.jpg)">
                    <div class="container">
                        <div class="row slide-margin">
                            <div class="col-sm-6">
                                <div class="carousel-content">
                                    <h1 class="animation animated-item-1">Lorem ipsum dolor sit amet consectetur adipisicing elit</h1>
                                    <h2 class="animation animated-item-2">Accusantium doloremque laudantium totam rem aperiam, eaque ipsa...</h2>
                                    <a class="btn-slide animation animated-item-3" href="#">Read More</a>
                                </div>
                            </div>

                            <div class="col-sm-6 hidden-xs animation animated-item-4">
                                <div class="slider-img">
                                    <img src="http://localhost/tut/corlate/images/slider/img2.png" class="img-responsive">
                                </div>
                            </div>

                        </div>
                    </div>
                </div><!--/.item-->
        

                <div class="item" style="background-image: url(http://localhost/tut/corlate/images/slider/bg3.jpg)">
                    <div class="container">
                        <div class="row slide-margin">
                            <div class="col-sm-6">
                                <div class="carousel-content">
                                    <h1 class="animation animated-item-1">Lorem ipsum dolor sit amet consectetur adipisicing elit</h1>
                                    <h2 class="animation animated-item-2">Accusantium doloremque laudantium totam rem aperiam, eaque ipsa...</h2>
                                    <a class="btn-slide animation animated-item-3" href="#">Read More</a>
                                </div>
                            </div>
                            <div class="col-sm-6 hidden-xs animation animated-item-4">
                                <div class="slider-img">
                                    <img src="http://localhost/tut/corlate/images/slider/img3.png" class="img-responsive">
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!--/.item-->
            </div><!--/.carousel-inner-->
        </div><!--/.carousel-->
        <a class="prev hidden-xs" href="#main-slider" data-slide="prev">
            <i class="fa fa-chevron-left"></i>
        </a>
        <a class="next hidden-xs" href="#main-slider" data-slide="next">
            <i class="fa fa-chevron-right"></i>
        </a>
    </section><!--/#main-slider-->


 <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
  
  <div class="col-md-8">

        
                      
            
                  <div class="box box-danger">
                <div class="box-header with-border">
                  <h3 class="box-title">Our services</h3>
              </div>

              <section id="services" class="service-item">
              <div class="row">
              <?php foreach($services as $service): ?>
                <div class="col-md-6 col-sm-6">
                    <div class="media services-wrap wow fadeInDown">                        
                            <img src="<?php echo e(asset('files/services/'.$service->picture.'')); ?>">
                        <h3 class="box-header"><?php echo e($service->title); ?></h3>
                        <div class="box-body">
                            <p><?php echo e(substr($service->service, 0, 200)); ?>.....
                              <a href="<?php echo e(url('services')); ?>" class="uppercase">Learn More</a></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
                <div class="box-footer">
                 <a href="<?php echo e(url('services')); ?>" class="uppercase">View other services</a>
                </div><!-- /.box-footer --> 


             </div><!--/.row-->
          </section><!--/#services-->
        </div>

          <?php /* our portfolio works start from here */ ?>

         <h2 class="newsh2">OUR PORTFOLIO</h2>

     <div class="row">

   <?php foreach($portfolios as $portfolio): ?>
   <div class="col-md-6 col-sm-6 col-xs-12 portfolio-main wow fadeInDown">

    <a href="<?php echo e(url('portfolio/'.$portfolio->id.'')); ?> "><img src="<?php echo e(asset('files/portfolio/'.$portfolio->image.'')); ?>" class="img-responsive"/></a>
    <p>
     <?php /* $portfolio-> */ ?>
     <h4><?php echo e($portfolio->name); ?></h4>
      <?php /* <h6><?php echo e($portfolio->title); ?></h6> */ ?>
     <strong>Client:</strong> <?php echo e($portfolio->client); ?> 
     <br><a href="<?php echo e(url('portfolio/'.$portfolio->id.'')); ?>" class="btn btn-primary btn-sm">Read More</a>
    </p>

    </div>
   <?php endforeach; ?>
 </div>




</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>
     
  <div class="col-md-4">

    
               <div class="box box-danger direct-testimony direct-testimony-danger wow fadeInDown">
                <div class="box-header with-border">
                  <h3 class="box-title">Testimonies</h3>
                 <div class="box-tools pull-right">
                    <a href="<?php echo e(url('testimonies/share')); ?>" class="fa fa-share-alt"></a>
                    <?php /*<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> */ ?>
                  </div
                   </div><!-- /.box-header --> 
                <div class="box-body">
                    <?php foreach($testimony as $ts): ?>
                    <div class="direct-testimony-msg">
                      <div class="direct-testimony-info clearfix">
                        <span class="direct-testimony-name pull-left"><?php echo e($ts->firstname); ?> <?php echo e($ts->lastname); ?></span>
                        <span class="direct-testimony-timestamp pull-right"> <?php echo e($ts->created_at->format('d M y')); ?></span>
                      </div><!-- /.direct-testimony-info -->
                      <img class="direct-testimony-img" src="<?php echo e(asset('files/testimony/'.$ts->image.'')); ?>" alt="" /><!-- /.direct-testimony-img -->
                      <div class="direct-testimony-text">
                        <?php echo e($ts->content); ?>

                      </div><!-- /.direct-testimony-text -->
                    </div><!-- /.direct-testimony-msg -->
                    <?php endforeach; ?>
                     </div><!-- /.box-body -->
                       <div class="box-footer text-center">
                  <a href="<?php echo e(url('testimonies')); ?>" class="uppercase">View All Testimonies</a>
                </div><!-- /.box-footer -->
                   </div><!--/.direct-testimony -->


                   <?php /* latest news start from here */ ?>

                 <div class="box box-danger direct-testimony direct-testimony-danger wow fadeInDown">
                <div class="box-header with-border">
                  <h3 class="box-title">Press release news</h3>
              </div>
              <div class="box-body">
                 <ul class="news-list news-list-in-box">
                <?php foreach($news as $new ): ?>

                  <li class="item">
                      <div class="news-img">
                        <img src="<?php echo e(asset('files/news/'.$new->picture.'')); ?>" alt="" />
                      </div>
                      <div class="news-info">
                        <a href="<?php echo e(url('news/'.$new->id.'')); ?>" class="news-title"> <?php echo e($new->title); ?> <span class="label label-warning pull-right"><?php echo e($new->created_at->format('d M Y')); ?></span></a>
                        <span class="news-description">
                          <?php echo e(substr($new->news, 0, 100)); ?>.... 
                        </span>
                      </div>
                    </li><!-- /.item -->
                <?php endforeach; ?>
            </div>
              </div><?php /* box body end */ ?>
               <div class="box-footer text-center">
                  <a href="<?php echo e(asset('files/news')); ?>" class="uppercase">View All News</a>
                </div><!-- /.box-footer -->
               </div>



               <?php /* Our develper start here */ ?>


                                 <!-- Developer LIST -->
                  <div class="box box-danger wow fadeInDown">
                    <div class="box-header with-border">
                      <h3 class="box-title">Our Teams</h3>
                      <div class="box-tools pull-right">
                        <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                        <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                      </div>
                    </div><!-- /.box-header -->
                    <div class="box-body no-padding">
                      <ul class="users-list">
            <?php foreach($developers as $developer): ?>             
                        <li>
                         <a href="<?php echo e(url('/developer/'.$developer->id.'')); ?>"> <img src="<?php echo e(asset('files/developer/picture/'.$developer->picture.'')); ?>" alt=""/></a>
                          <a class="users-list-name" href="<?php echo e(url('/developer/'.$developer->id.'')); ?>"><?php echo e($developer->firstname); ?> <?php echo e($developer->lastname); ?></a>
                          <span class="users-list-date"><?php echo e($developer->position); ?></span>
                        </li>            
            <?php endforeach; ?>            
                </ul><!-- /.users-list -->
                    </div><!-- /.box-body -->
                    <div class="box-footer text-center">
                      <a href="<?php echo e(url('developer')); ?>" class="uppercase">View All Teams member</a>
                    </div><!-- /.box-footer -->
                  </div><!--/.box -->



</div> <?php /* col-md-4 */ ?>    
<?php $__env->stopSection(); ?>


   

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>