<?php $__env->startSection('content'); ?>





 <div class="container">


                  <a href="<?php echo e(url('/admin/about')); ?>" class="quick-button metro yellow col-md-2">
					<i class="fa fa-bookmark-o"></i>
					<p>About</p>
					</a>
				
				<a href="<?php echo e(url('/admin/contact')); ?>"class="quick-button metro pink col-md-2">
					<i class="fa fa-envelope"></i>
					<p>Contact Messages</p>
					<span class="badge">88</span>
				</a>
				 <a href="<?php echo e(url('/admin/developer')); ?>" class="quick-button metro blue col-md-2">
					<i class="fa fa-group"></i>
					<p>Developers</p>
					<span class="badge">237</span>
				</a>

                   <a href="<?php echo e(url('/admin/media')); ?>"class="quick-button metro red col-md-2">
					<i class="fa fa-camera"></i>
					<p>media</p>
					<span class="badge">237</span>
				</a>

					<a href="<?php echo e(url('/admin/news')); ?>" class="quick-button metro purple col-md-2">
					<i class="fa fa-rss"></i>
					<p>news</p>
				      </a>
				
				<a href="<?php echo e(url('/admin/pages')); ?>" class="quick-button metro yellow col-md-2">
					<i class="fa fa-th-large"></i>
					<p>Page++</p>
				</a>
				
					<a href="<?php echo e(url('/admin/portfolio')); ?>" class="quick-button metro blue col-md-2">
					<i class="fa fa-briefcase"></i>
					<p>portfolios</p>
					<span class="badge">13</span>
				     </a>

				     <a href="<?php echo e(url('/admin/proposal')); ?>" class="quick-button metro yellow col-md-2">
					<i class="fa fa-tasks"></i>
					<p>proposal</p>
					<span class="badge">13</span>
				     </a>

				<a href="<?php echo e(url('/admin/services')); ?>" class="quick-button metro red col-md-2">
					<i class="fa  fa-cutlery"></i>
					<p>services</p>
				</a>

					<a href="<?php echo e(url('/admin/settings')); ?>" class="quick-button metro black col-md-2">
					<i class="fa fa-cog"></i>
					<p>settings</p>
					<span class="badge">46</span>
				</a>

				<a href="<?php echo e(url('/admin/sliders')); ?>" class="quick-button metro yellow col-md-2">
					<i class="fa fa-exchange"></i>
					<p>sliders</p>
				</a>

				<a href="<?php echo e(url('/admin/support')); ?>" class="quick-button metro blue col-md-2">
					<i class="fa fa-phone-square"></i>
					<p>support</p>
				</a>

				<a href="<?php echo e(url('/admin/testimonies')); ?>" class="quick-button metro black col-md-2">
					<i class="fa  fa-thumbs-up"></i>
					<p>testimony</p>
				</a>
				
			
				
				<div class="clearfix"></div>
				
				</div>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>