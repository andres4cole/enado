<?php $__env->startSection('headerapp'); ?>
 <section id="conatcat-info">
        <div class="container">
            <div class="row">
                <div class="col-sm-8">
                    <div class="media contact-info wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
                        <div class="pull-left">
                            <i class="fa fa-arrow-circle-right "></i>
                        </div>
                        <div class="media-body">
                            <h2>Have a website with us?</h2>
                            <p> <a href="<?php echo e(url('/testimonies/share')); ?>" class="btn btn-warning btn-sm">share</a> your testimony and experience  with us </p>
                        </div>
                    </div>
                </div>
            </div>
        </div><!--/.container-->    
    </section><!--/#conatcat-info-->
  <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

             <section id="content">
			 <div class="col-md-8 wow fadeInDown">
                    <div class="testimonial">
                 <?php foreach($testimony as $ts ): ?>
                      <div class="testimonial-inner">
                        
                            <div class="pull-left">
                               <img src="<?php echo e(asset('files/testimony/'.$ts->image.'')); ?>" class="img-responsive img-thumbnail testimonyimage">
                                 <?php /* <img class="img-responsive " src="<?php echo e(asset('cpx/images/testimonials1.png')); ?>"> */ ?>
                            </div>
                            <div class="panel-heading">
                            	<h2> <?php echo e($ts->title); ?> </h2>
                            </div>
                            <div class="media-body">
                                <p> <?php echo e($ts->content); ?></p>
                                <span><strong> <?php echo e($ts->firstname); ?> <?php echo e($ts->lastname); ?></strong></span>
                               <br> <strong><?php echo e($ts->position); ?> at <?php echo e($ts->company); ?> </strong></br>
                               <span>website: <a href="<?php echo e($ts->website); ?>"><?php echo e($ts->website); ?></a> </sapn>
                            </div>

                         </div><?php /* testimonial inner */ ?>
            <?php endforeach; ?>
                <span> <?php echo $testimony->render(); ?></span>
            </div><!--/.row-->
          </div>
    </section><!--/#content-->

<?php $__env->stopSection(); ?>



<?php $__env->startSection('sidebar'); ?>

<?php echo $__env->make('include.proposal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>