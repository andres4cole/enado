<?php $__env->startSection('content'); ?>


	<div class="col-sm-6">
						<div class="portfolio-item">
							<div class="portfolio-image">
	<a href="<?php echo e(url('admin/portfolio/v/'.$portfolio->id.'')); ?> "> <img src="<?php echo e(asset('/files/portfolio/'.$portfolio->image.'')); ?>" alt="<?php echo e($portfolio->name); ?>"></a>

							</div>
						</div>
					</div>
					<!-- End Image Column -->
					<!-- Project Info Column -->
					
					<div class="portfolio-item-description col-sm-6">
						<div class="panel">
							<div class="box-header box-solid">
						<h3>Portfolio Description</h3>
					</div>
					<div class="box-body">
						<p>
						<?php echo e($portfolio->description); ?>

						</p>


							<br><strong>Client:</strong> <?php echo e($portfolio->client); ?>.</br>
							<span><strong>budget:</strong> <?php echo e($portfolio->budget); ?></span>
							<br><strong>Cost:</strong> <?php echo e($portfolio->cost); ?></br>
							<span><strong> Start Date:</strong> <?php echo e($portfolio->created_at->format('M d, Y')); ?> </span> 
							<br><strong>End Date:</strong> <?php echo e($portfolio->end_time); ?></br>
							<span><strong>Technologies:</strong> <?php echo e($portfolio->technologies); ?></span>
						</div>
						<div class="box-footer box-solid">
							<li class="btn btn-default"><a href="<?php echo e($portfolio->website); ?>">Visit Website</a></li>
					        <li class="read-more btn-line"><a href=" <?php echo e(url('admin/portfolio/'.$portfolio->id.'/edit')); ?> " class="btn btn-default">Edit</a></li>
					  <li><form role="form" method="post" action="<?php echo e(url('admin/portfolio/'.$portfolio->id.'/delete')); ?>" id="form">
                      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                      <input type="hidden" name="_method" value="delete">
                      <input type="hidden" name="id" value="<?php echo e($portfolio->id); ?>">
                      <button class="fa fa-trash-o"></button>
					  </form>
					</li>
						 </div>
				        </div>
			          </div>
					<!-- End Project Info Column -->
				</div>
			</div>
						

<?php $__env->stopSection(); ?>



<?php $__env->startSection('sidebar'); ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>