
@extends('app')


@section('headerapp')
 <section id="conatcat-info">
        <div class="container">
            <div class="row">
                <div class="col-sm-8">
                    <div class="media contact-info wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
                        <div class="pull-left">
                            <i class="fa fa-arrow-circle-right "></i>
                        </div>
                        <div class="media-body">
                            <h2>Have a website with us?</h2>
                            <p> <a href="{{url('/testimonies/share')}}" class="btn btn-warning btn-sm">share</a> your testimony and experience  with us </p>
                        </div>
                    </div>
                </div>
            </div>
        </div><!--/.container-->    
    </section><!--/#conatcat-info-->
  @endsection

@section('content')

             <section id="content">
			 <div class="col-md-8 wow fadeInDown">
                    <div class="testimonial">
                 @foreach($testimony as $ts )
                      <div class="testimonial-inner">
                        
                            <div class="pull-left">
                               <img src="{{asset('files/testimony/'.$ts->image.'')}}" class="img-responsive img-thumbnail testimonyimage">
                                 {{-- <img class="img-responsive " src="{{ asset('cpx/images/testimonials1.png')}}"> --}}
                            </div>
                            <div class="panel-heading">
                            	<h2> {{ $ts->title }} </h2>
                            </div>
                            <div class="media-body">
                                <p> {{ $ts->content }}</p>
                                <span><strong> {{ $ts->firstname }} {{ $ts->lastname }}</strong></span>
                               <br> <strong>{{ $ts->position }} at {{ $ts->company }} </strong></br>
                               <span>website: <a href="{{ $ts->website}}">{{ $ts->website }}</a> </sapn>
                            </div>

                         </div>{{-- testimonial inner --}}
            @endforeach
                <span> {!! $testimony->render() !!}</span>
            </div><!--/.row-->
          </div>
    </section><!--/#content-->

@endsection



@section('sidebar')

@include('include.proposal')

@endsection