
@extends('app')

@section('headerapp')
<section id="headerapp" style="background-image: url('{{ asset('/frontend/images/wps.jpg')}}')">
    <h2 class="newsh">our services</h2>
</section>
@endsection


@section('content')
         
                <div class="services service-item">
              @foreach ($services as $service)
                <div class="col-sm-6 col-md-4">
                    <div class="media services-wrap wow fadeInDown">                        
                        <img src="{{ asset('files/services/'.$service->picture.'') }}">
                        <h3 class="box-header">{{ $service->title }}</h3>
                        <div class="box-body">
                            <p>{{$service->service }}</p>
                        </div>
                    </div>
                </div>
                @endforeach

          </div><!--/#services-->

@endsection



@section('sidebar')


@endsection