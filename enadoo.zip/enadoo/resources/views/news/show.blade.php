
@extends('app')

@section('headerapp')
<section id="headerapp" style="background-image: url('{{ asset('/frontend/images/wps.jpg')}}')">
    <h2 class="newsh">Press Release</h2>
</section>
@endsection
@section('content')


       
                     
				             <div class="col-md-8 news">
					         <h2 class="newsh2"> {{ $news->title }}</h2>
							<img src="{{ asset('files/news/'.$news->picture.'') }}" title="name" />
							 <span>{{$news->created_at->format('d M Y')}} {{-- by <a href="#">Admin</a></span> --}}
							 <p> {{ $news->news }}.... </p>
				             </div>
			             



@endsection



@section('sidebar')

@include('include.proposal')
@endsection