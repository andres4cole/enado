@extends('admin')

@section('content')





 <div class="container">


                  <a href="{{ url('/admin/about') }}" class="quick-button metro yellow col-md-2">
					<i class="fa fa-bookmark-o"></i>
					<p>About</p>
					</a>
				
				<a href="{{ url('/admin/contact') }}"class="quick-button metro pink col-md-2">
					<i class="fa fa-envelope"></i>
					<p>Contact Messages</p>
					<span class="badge">88</span>
				</a>
				 <a href="{{ url('/admin/developer') }}" class="quick-button metro blue col-md-2">
					<i class="fa fa-group"></i>
					<p>Developers</p>
					<span class="badge">237</span>
				</a>

                   <a href="{{ url('/admin/media') }}"class="quick-button metro red col-md-2">
					<i class="fa fa-camera"></i>
					<p>media</p>
					<span class="badge">237</span>
				</a>

					<a href="{{ url('/admin/news') }}" class="quick-button metro purple col-md-2">
					<i class="fa fa-rss"></i>
					<p>news</p>
				      </a>
				
				<a href="{{ url('/admin/pages') }}" class="quick-button metro yellow col-md-2">
					<i class="fa fa-th-large"></i>
					<p>Page++</p>
				</a>
				
					<a href="{{ url('/admin/portfolio') }}" class="quick-button metro blue col-md-2">
					<i class="fa fa-briefcase"></i>
					<p>portfolios</p>
					<span class="badge">13</span>
				     </a>

				     <a href="{{ url('/admin/proposal') }}" class="quick-button metro yellow col-md-2">
					<i class="fa fa-tasks"></i>
					<p>proposal</p>
					<span class="badge">13</span>
				     </a>

				<a href="{{ url('/admin/services') }}" class="quick-button metro red col-md-2">
					<i class="fa  fa-cutlery"></i>
					<p>services</p>
				</a>

					<a href="{{ url('/admin/settings') }}" class="quick-button metro black col-md-2">
					<i class="fa fa-cog"></i>
					<p>settings</p>
					<span class="badge">46</span>
				</a>

				<a href="{{ url('/admin/sliders') }}" class="quick-button metro yellow col-md-2">
					<i class="fa fa-exchange"></i>
					<p>sliders</p>
				</a>

				<a href="{{ url('/admin/support') }}" class="quick-button metro blue col-md-2">
					<i class="fa fa-phone-square"></i>
					<p>support</p>
				</a>

				<a href="{{ url('/admin/testimonies') }}" class="quick-button metro black col-md-2">
					<i class="fa  fa-thumbs-up"></i>
					<p>testimony</p>
				</a>
				
			
				
				<div class="clearfix"></div>
				
				</div>







@endsection