
@extends('app')


@section('content')


 <div class="col-md-6 col-sm-6 portfolio-main">
 	<h2 class="newsh2">{{ $portfolio->name }}</h2>
   	<img src="{{ asset('files/portfolio/'.$portfolio->image.'') }}"/>
   </div>

 <div class="col-md-6 col-sm-6 portfolio-main">
    <h2 class="newsh2">{{ $portfolio->title }}</h2>
  	           <div class="panel-body">
						<p>
						{{ $portfolio->description}}
						</p>
					  <ul>
							<li><b>Client:</b> {{$portfolio->client}}.</li>
							<li><b>budget:</b> {{$portfolio->budget}}</li>
							 <li><b>Cost:</b> {{$portfolio->cost}}</li>
							<li><b>Start Date:</b> {{$portfolio->created_at->format('M d, Y')}} </li> 
							<li><b>End Date:</b> {{$portfolio->end_time }}</li>
							<li><b>Technologies:</b> {{$portfolio->technologies}}</li>
							<li class="btn btn-primary btn-sm"><a href="{{$portfolio->website}}">Visit Website</a></li>
					      </ul>  
					</div>
    </div>

@endsection



@section('sidebar')

@endsection