
@extends('app')

@section('headerapp')
<section id="headerapp" style="background-image: url('{{ asset('/frontend/images/port-1.jpg')}}')">
    <h2 class="newsh">Portfolio</h2>
</section>
@endsection

@section('content')

  <div class="col-md-8">
	<h2 class="newsh2">OUR PORTFOLIO</h2>

     <div class="row">

   @foreach($portfolios as $portfolio)
   <div class="col-md-6 col-sm-6 col-xs-12 portfolio-main">

   	<a href="{{ url('portfolio/'.$portfolio->id.'') }} "><img src="{{ asset('files/portfolio/'.$portfolio->image.'') }}" class="img-responsive"/></a>
    <p>
     {{-- $portfolio-> --}}
     <h4>{{ $portfolio->name }}</h4>
      <h6>{{ $portfolio->title }}</h6>
     <strong>Client:</strong> {{ $portfolio->client }}
     <br><a href="{{ url('portfolio/'.$portfolio->id.'') }}" class="btn btn-primary btn-sm">Read More</a>
    </p>

    </div>
   @endforeach

    {!! $portfolios->render() !!}
</div>
</div>

@endsection



@section('sidebar')
@include('include.proposal')

@endsection