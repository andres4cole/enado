<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class mdeveloper extends Model
{
    //
    protected $table = 'developers';
}
