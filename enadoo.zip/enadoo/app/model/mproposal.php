<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class mproposal extends Model
{
    //
     protected $table = 'proposals';
}
