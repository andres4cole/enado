<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class msettings extends Model
{
    //
      protected $table = 'settings';
}
