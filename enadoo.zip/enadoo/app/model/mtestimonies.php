<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class mtestimonies extends Model
{
    //
      protected $table = 'testimonies';
}
