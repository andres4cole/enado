<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class mabouts extends Model
{
    //
     protected $table = 'abouts';
}
