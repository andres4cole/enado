<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class mnews extends Model
{
    //
     protected $table = 'news';
}
