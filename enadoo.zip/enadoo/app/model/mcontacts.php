<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class mcontacts extends Model
{
    //
    protected $table = 'contacts';
}
