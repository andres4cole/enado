<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class msliders extends Model
{
    //
      protected $table = 'sliders';
}
