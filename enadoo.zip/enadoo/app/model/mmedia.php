<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class mmedia extends Model
{
    //
     protected $table = 'media';
}
