<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class mpages extends Model
{
    //
         protected $table = 'pages';
}
