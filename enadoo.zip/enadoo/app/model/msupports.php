<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class msupports extends Model
{
    //
     protected $table = 'supports';
}
